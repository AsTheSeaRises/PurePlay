import { c as STORAGE_KEYS, D as DEFAULT_SETTINGS } from "./constants-CvA2GUOI.js";
async function get(key, fallback) {
  const result = await chrome.storage.local.get(key);
  return key in result ? result[key] : fallback;
}
async function set(key, value) {
  await chrome.storage.local.set({ [key]: value });
}
const storage = {
  async getAuthToken() {
    const result = await chrome.storage.session.get("authToken");
    return result["authToken"] ?? null;
  },
  async setAuthToken(token, username) {
    await chrome.storage.session.set({ authToken: token });
    await set(STORAGE_KEYS.USERNAME, username);
  },
  async getUsername() {
    return get(STORAGE_KEYS.USERNAME, null);
  },
  async getLastSyncSha() {
    return get(STORAGE_KEYS.LAST_SYNC_SHA, null);
  },
  async setLastSyncSha(sha) {
    await set(STORAGE_KEYS.LAST_SYNC_SHA, sha);
    await set(STORAGE_KEYS.LAST_SYNC_TIMESTAMP, Date.now());
  },
  async getLastSyncTimestamp() {
    return get(STORAGE_KEYS.LAST_SYNC_TIMESTAMP, null);
  },
  async getLastKnownArtistIds() {
    return get(STORAGE_KEYS.LAST_KNOWN_ARTIST_IDS, []);
  },
  async setLastKnownArtistIds(ids) {
    await set(STORAGE_KEYS.LAST_KNOWN_ARTIST_IDS, ids);
  },
  async getBlockedArtistIds() {
    return get(STORAGE_KEYS.BLOCKED_ARTIST_IDS, []);
  },
  async addBlockedArtistIds(ids) {
    const existing = await this.getBlockedArtistIds();
    const merged = Array.from(/* @__PURE__ */ new Set([...existing, ...ids]));
    await set(STORAGE_KEYS.BLOCKED_ARTIST_IDS, merged);
    const added = merged.length - existing.length;
    if (added > 0) {
      const session = await get(STORAGE_KEYS.SESSION_BLOCK_COUNT, 0);
      const total = await get(STORAGE_KEYS.TOTAL_BLOCK_COUNT, 0);
      await set(STORAGE_KEYS.SESSION_BLOCK_COUNT, session + added);
      await set(STORAGE_KEYS.TOTAL_BLOCK_COUNT, total + added);
    }
  },
  async getBlockCounts() {
    const session = await get(STORAGE_KEYS.SESSION_BLOCK_COUNT, 0);
    const total = await get(STORAGE_KEYS.TOTAL_BLOCK_COUNT, 0);
    return { session, total };
  },
  async resetSessionCount() {
    await set(STORAGE_KEYS.SESSION_BLOCK_COUNT, 0);
  },
  async getRetryQueue() {
    return get(STORAGE_KEYS.RETRY_QUEUE, []);
  },
  async setRetryQueue(queue) {
    await set(STORAGE_KEYS.RETRY_QUEUE, queue);
  },
  async getSettings() {
    return get(STORAGE_KEYS.SETTINGS, DEFAULT_SETTINGS);
  },
  async setSettings(settings) {
    await set(STORAGE_KEYS.SETTINGS, settings);
  },
  async getWhitelist() {
    return get(STORAGE_KEYS.WHITELIST, []);
  },
  async addToWhitelist(entry) {
    const list = await this.getWhitelist();
    if (!list.find((e) => e.id === entry.id)) {
      await set(STORAGE_KEYS.WHITELIST, [...list, entry]);
    }
  },
  async getWhitelistIds() {
    const list = await this.getWhitelist();
    return new Set(list.map((e) => e.id));
  },
  async getHeuristicScores() {
    return get(STORAGE_KEYS.HEURISTIC_SCORES, {});
  },
  async setHeuristicScore(artistId, score) {
    const scores = await this.getHeuristicScores();
    scores[artistId] = score;
    await set(STORAGE_KEYS.HEURISTIC_SCORES, scores);
  },
  async getFlaggedArtists() {
    return get(STORAGE_KEYS.FLAGGED_ARTISTS, []);
  },
  async addFlaggedArtist(artist) {
    const flagged = await this.getFlaggedArtists();
    if (!flagged.find((a) => a.id === artist.id)) {
      await set(STORAGE_KEYS.FLAGGED_ARTISTS, [...flagged, artist]);
    }
  },
  async removeFlaggedArtist(artistId) {
    const flagged = await this.getFlaggedArtists();
    await set(
      STORAGE_KEYS.FLAGGED_ARTISTS,
      flagged.filter((a) => a.id !== artistId)
    );
  },
  async getErrors() {
    return get(STORAGE_KEYS.ERRORS, []);
  },
  async addError(entry) {
    const errors = await this.getErrors();
    const deduped = errors.filter((e) => e.resolved || e.message !== entry.message);
    const newErrors = [
      { ...entry, timestamp: Date.now(), resolved: false },
      ...deduped
    ].slice(0, 50);
    await set(STORAGE_KEYS.ERRORS, newErrors);
  },
  async clearResolvedErrors() {
    const errors = await this.getErrors();
    await set(STORAGE_KEYS.ERRORS, errors.filter((e) => !e.resolved));
  },
  async clearErrors() {
    await set(STORAGE_KEYS.ERRORS, []);
  },
  async getArtistNameMap() {
    return get(STORAGE_KEYS.ARTIST_NAME_MAP, {});
  },
  async setArtistNameMap(map) {
    await set(STORAGE_KEYS.ARTIST_NAME_MAP, map);
  },
  async clearAll() {
    await chrome.storage.local.clear();
    await chrome.storage.session.clear();
  }
};
export {
  storage as s
};
