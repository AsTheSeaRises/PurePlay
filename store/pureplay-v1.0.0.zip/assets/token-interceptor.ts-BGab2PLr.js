import { T as TOKEN_MESSAGE_TYPE } from "./constants-CvA2GUOI.js";
window.addEventListener("message", (event) => {
  if (event.origin !== "https://open.spotify.com" || !event.data || event.data.type !== TOKEN_MESSAGE_TYPE) {
    return;
  }
  const { token, username } = event.data;
  if (!token) return;
  chrome.runtime.sendMessage({
    type: "AUTH_TOKEN",
    token,
    username: username ?? ""
  });
});
const ARTIST_HREF_RE = /^\/artist\/([A-Za-z0-9]+)$/;
const seenIds = /* @__PURE__ */ new Set();
let pendingArtists = [];
let debounceTimer = null;
function flush() {
  if (pendingArtists.length === 0) return;
  chrome.runtime.sendMessage({ type: "ARTISTS_ENCOUNTERED", artists: pendingArtists });
  pendingArtists = [];
}
function scanNodes(nodes) {
  nodes.forEach((node) => {
    var _a;
    if (!(node instanceof Element)) return;
    const anchors = [];
    if (node instanceof HTMLAnchorElement) anchors.push(node);
    anchors.push(...Array.from(node.querySelectorAll("a[href]")));
    for (const anchor of anchors) {
      const href = anchor.getAttribute("href") ?? "";
      const match = ARTIST_HREF_RE.exec(href);
      if (!match) continue;
      const id = match[1];
      if (seenIds.has(id)) continue;
      seenIds.add(id);
      const name = ((_a = anchor.textContent) == null ? void 0 : _a.trim()) ?? "";
      pendingArtists.push({ id, name });
    }
  });
  if (pendingArtists.length > 0) {
    if (debounceTimer !== null) clearTimeout(debounceTimer);
    debounceTimer = self.setTimeout(flush, 1e3);
  }
}
const observer = new MutationObserver((mutations) => {
  for (const mutation of mutations) {
    scanNodes(mutation.addedNodes);
  }
});
function startObserver() {
  observer.observe(document.body, { childList: true, subtree: true });
  scanNodes(document.body.childNodes);
}
if (document.body) {
  startObserver();
} else {
  document.addEventListener("DOMContentLoaded", startObserver, { once: true });
}
