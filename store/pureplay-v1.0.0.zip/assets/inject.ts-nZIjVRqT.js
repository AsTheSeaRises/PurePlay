import { T as TOKEN_MESSAGE_TYPE } from "./constants-CvA2GUOI.js";
const originalFetch = window.fetch.bind(window);
let capturedToken = null;
function extractUsername() {
  for (let i = 0; i < localStorage.length; i++) {
    const key = localStorage.key(i);
    if (key && key.includes(":") && !key.startsWith("anonymous:")) {
      return key.split(":")[0];
    }
  }
  return null;
}
window.fetch = async function(input, init) {
  const headers = init == null ? void 0 : init.headers;
  if (headers) {
    let authorization;
    if (headers instanceof Headers) {
      authorization = headers.get("authorization") ?? void 0;
    } else if (Array.isArray(headers)) {
      const found = headers.find(([k]) => k.toLowerCase() === "authorization");
      authorization = found == null ? void 0 : found[1];
    } else {
      const record = headers;
      authorization = record["authorization"] ?? record["Authorization"];
    }
    if (authorization && authorization !== capturedToken) {
      capturedToken = authorization;
      const username = extractUsername();
      window.postMessage(
        { type: TOKEN_MESSAGE_TYPE, token: authorization, username },
        "https://open.spotify.com"
      );
    }
  }
  return originalFetch(input, init);
};
