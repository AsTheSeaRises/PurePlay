const CSV_REPO_OWNER = "CennoxX";
const CSV_REPO_NAME = "spotify-ai-blocker";
const CSV_FILE_PATH = "SpotifyAiArtists.csv";
const CSV_RAW_URL = `https://raw.githubusercontent.com/${CSV_REPO_OWNER}/${CSV_REPO_NAME}/main/${CSV_FILE_PATH}`;
const CSV_COMMITS_API_URL = `https://api.github.com/repos/${CSV_REPO_OWNER}/${CSV_REPO_NAME}/commits?path=${CSV_FILE_PATH}&per_page=1`;
const SPOTIFY_BLOCK_API = "https://spclient.wg.spotify.com/collection/v2/write";
const SPOTIFY_API_BASE = "https://api.spotify.com/v1";
const ALARM_NAME = "pureplay-sync";
const TOKEN_MESSAGE_TYPE = "PUREPLAY_TOKEN";
const BLOCK_BATCH_SIZE = 50;
const MAX_RETRY_ATTEMPTS = 5;
const RETRY_EXPIRY_MS = 7 * 24 * 60 * 60 * 1e3;
const DEFAULT_SETTINGS = {
  syncFrequencyHours: 24,
  heuristicsEnabled: false,
  autoBlockThreshold: 80,
  flagThreshold: 50,
  unblockRemovedArtists: false,
  csvSourceUrl: CSV_RAW_URL
};
const GITHUB_REPORT_URL = `https://github.com/${CSV_REPO_OWNER}/${CSV_REPO_NAME}/issues/new`;
const STORAGE_KEYS = {
  USERNAME: "username",
  LAST_SYNC_SHA: "lastSyncSha",
  LAST_SYNC_TIMESTAMP: "lastSyncTimestamp",
  LAST_KNOWN_ARTIST_IDS: "lastKnownArtistIds",
  BLOCKED_ARTIST_IDS: "blockedArtistIds",
  SESSION_BLOCK_COUNT: "sessionBlockCount",
  TOTAL_BLOCK_COUNT: "totalBlockCount",
  RETRY_QUEUE: "retryQueue",
  HEURISTIC_SCORES: "heuristicScores",
  FLAGGED_ARTISTS: "flaggedArtists",
  WHITELIST: "whitelist",
  SETTINGS: "settings",
  ERRORS: "errors",
  ARTIST_NAME_MAP: "artistNameMap"
};
export {
  ALARM_NAME as A,
  BLOCK_BATCH_SIZE as B,
  CSV_RAW_URL as C,
  DEFAULT_SETTINGS as D,
  GITHUB_REPORT_URL as G,
  MAX_RETRY_ATTEMPTS as M,
  RETRY_EXPIRY_MS as R,
  SPOTIFY_BLOCK_API as S,
  TOKEN_MESSAGE_TYPE as T,
  CSV_COMMITS_API_URL as a,
  SPOTIFY_API_BASE as b,
  STORAGE_KEYS as c
};
