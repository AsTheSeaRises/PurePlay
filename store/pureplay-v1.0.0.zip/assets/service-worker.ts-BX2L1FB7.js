import { B as BLOCK_BATCH_SIZE, S as SPOTIFY_BLOCK_API, M as MAX_RETRY_ATTEMPTS, C as CSV_RAW_URL, a as CSV_COMMITS_API_URL, b as SPOTIFY_API_BASE, R as RETRY_EXPIRY_MS, A as ALARM_NAME } from "./constants-CvA2GUOI.js";
import { s as storage } from "./storage-DoDsk7hb.js";
async function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}
async function blockBatch(ids, username, token) {
  const payload = {
    username,
    set: "artistban",
    items: ids.map((id) => ({ uri: `spotify:artist:${id}` }))
  };
  for (let attempt = 0; attempt < MAX_RETRY_ATTEMPTS; attempt++) {
    try {
      const res = await fetch(`${SPOTIFY_BLOCK_API}?market=from_token`, {
        method: "POST",
        headers: {
          Authorization: token,
          "Content-Type": "application/json"
        },
        body: JSON.stringify(payload)
      });
      if (res.ok) {
        return { success: true };
      }
      if (res.status === 401) {
        return { success: false };
      }
      if (res.status === 429) {
        const retryAfter = parseInt(res.headers.get("Retry-After") ?? "0", 10);
        const waitMs = retryAfter > 0 ? retryAfter * 1e3 : Math.pow(2, attempt) * 1e3;
        if (attempt < MAX_RETRY_ATTEMPTS - 1) {
          await sleep(waitMs);
          continue;
        }
        return { success: false, retryAfterMs: waitMs };
      }
      if (res.status >= 500) {
        if (attempt < MAX_RETRY_ATTEMPTS - 1) {
          await sleep(Math.pow(2, attempt) * 1e3);
          continue;
        }
      }
      return { success: false };
    } catch {
      if (attempt < MAX_RETRY_ATTEMPTS - 1) {
        await sleep(Math.pow(2, attempt) * 1e3);
        continue;
      }
      return { success: false };
    }
  }
  return { success: false };
}
async function blockArtists(artists, username, token) {
  const blocked = [];
  const failed = [];
  const batches = [];
  for (let i = 0; i < artists.length; i += BLOCK_BATCH_SIZE) {
    batches.push(artists.slice(i, i + BLOCK_BATCH_SIZE).map((a) => a.id));
  }
  for (const batch of batches) {
    const result = await blockBatch(batch, username, token);
    if (result.success) {
      blocked.push(...batch);
    } else {
      failed.push(...batch);
    }
  }
  return { blocked, failed };
}
async function unblockArtists(artistIds, username, token) {
  const blocked = [];
  const failed = [];
  const batches = [];
  for (let i = 0; i < artistIds.length; i += BLOCK_BATCH_SIZE) {
    batches.push(artistIds.slice(i, i + BLOCK_BATCH_SIZE));
  }
  for (const batch of batches) {
    try {
      const res = await fetch(`${SPOTIFY_BLOCK_API}?market=from_token`, {
        method: "POST",
        headers: {
          Authorization: token,
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          username,
          set: "artistban",
          remove_items: batch.map((id) => ({ uri: `spotify:artist:${id}` }))
        })
      });
      if (res.ok) {
        blocked.push(...batch);
      } else {
        failed.push(...batch);
      }
    } catch {
      failed.push(...batch);
    }
  }
  return { blocked, failed };
}
async function fetchLatestSha() {
  var _a;
  try {
    const res = await fetch(CSV_COMMITS_API_URL);
    if (!res.ok) return null;
    const commits = await res.json();
    return ((_a = commits[0]) == null ? void 0 : _a.sha) ?? null;
  } catch {
    return null;
  }
}
function parseCsv(text) {
  const lines = text.trim().split("\n");
  const entries = [];
  for (let i = 1; i < lines.length; i++) {
    const line = lines[i].trim();
    if (!line) continue;
    const parts = line.split(",");
    if (parts.length < 2) continue;
    const name = parts[0].replace(/^"|"$/g, "").trim();
    const id = parts[parts.length - 1].replace(/^"|"$/g, "").trim();
    if (id) {
      entries.push({ id, name });
    }
  }
  return entries;
}
async function fetchCsv(url) {
  const res = await fetch(url);
  if (!res.ok) {
    throw new Error(`Failed to fetch CSV: ${res.status} ${res.statusText}`);
  }
  const text = await res.text();
  return parseCsv(text);
}
async function fetchAndDiff(csvUrl = CSV_RAW_URL) {
  const latestSha = await fetchLatestSha();
  const lastSha = await storage.getLastSyncSha();
  if (latestSha && latestSha === lastSha) {
    return null;
  }
  const fullList = await fetchCsv(csvUrl);
  const currentIds = new Set(fullList.map((a) => a.id));
  const lastIds = new Set(await storage.getLastKnownArtistIds());
  const newArtists = fullList.filter((a) => !lastIds.has(a.id));
  const removedArtistIds = [...lastIds].filter((id) => !currentIds.has(id));
  const removedArtists = removedArtistIds.map((id) => ({ id, name: "" }));
  const sha = latestSha ?? `hash-${Date.now()}`;
  return { newArtists, removedArtists, fullList, sha };
}
async function spotifyGet(path, token) {
  try {
    const res = await fetch(`${SPOTIFY_API_BASE}${path}`, {
      headers: { Authorization: token }
    });
    if (!res.ok) return null;
    return res.json();
  } catch {
    return null;
  }
}
function stdDev(values) {
  if (values.length === 0) return 0;
  const mean = values.reduce((a, b) => a + b, 0) / values.length;
  const variance = values.reduce((sum, v) => sum + Math.pow(v - mean, 2), 0) / values.length;
  return Math.sqrt(variance);
}
function monthsBetween(dateA, dateB) {
  const a = new Date(dateA);
  const b = new Date(dateB);
  return Math.abs((b.getFullYear() - a.getFullYear()) * 12 + (b.getMonth() - a.getMonth()));
}
const AI_NAME_PATTERNS = [
  /^[a-z\s]+$/,
  // all lowercase, no uppercase at all
  /\b(lofi|lo-fi|chill|study|sleep|relax|focus|ambient)\b/i,
  /^\w+\s+(beats?|sounds?|music|vibes?|waves?)$/i,
  /^(the\s+)?\w+\s+\w+\s+(project|collective|ensemble)$/i
];
function scoreNamingPatterns(name) {
  let matches = 0;
  for (const pattern of AI_NAME_PATTERNS) {
    if (pattern.test(name)) matches++;
  }
  return Math.min(matches * 5, 10);
}
async function scoreArtist(artist, token) {
  const artistData = await spotifyGet(`/artists/${artist.id}`, token);
  if (!artistData) return null;
  const signals = {};
  let totalScore = 0;
  signals.namingPatterns = scoreNamingPatterns(artistData.name);
  totalScore += signals.namingPatterns;
  const { total: followers } = artistData.followers;
  if (followers < 100 && artistData.popularity > 10) {
    signals.lowFollowers = 10;
  } else if (followers < 500) {
    signals.lowFollowers = 5;
  } else {
    signals.lowFollowers = 0;
  }
  totalScore += signals.lowFollowers;
  const externalKeys = Object.keys(artistData.external_urls);
  signals.missingLinks = externalKeys.length <= 1 ? 15 : 0;
  totalScore += signals.missingLinks;
  const albumsData = await spotifyGet(
    `/artists/${artist.id}/albums?limit=50&include_groups=single,album`,
    token
  );
  if (albumsData && albumsData.items.length > 0) {
    const albums = albumsData.items;
    const totalTracks = albums.reduce((sum, a) => sum + a.total_tracks, 0);
    const dates = albums.map((a) => a.release_date).filter(Boolean).sort();
    const spanMonths = dates.length >= 2 ? monthsBetween(dates[0], dates[dates.length - 1]) : 0;
    const tracksPerMonth = spanMonths > 0 ? totalTracks / spanMonths : totalTracks;
    if (tracksPerMonth >= 16 || totalTracks >= 50 && spanMonths <= 3) {
      signals.catalogueVelocity = 30;
    } else if (tracksPerMonth >= 8) {
      signals.catalogueVelocity = 15;
    } else {
      signals.catalogueVelocity = 0;
    }
    totalScore += signals.catalogueVelocity;
    if (albums[0]) {
      const tracksData = await spotifyGet(
        `/albums/${albums[0].id}/tracks?limit=50`,
        token
      );
      if (tracksData && tracksData.items.length > 0) {
        const durations = tracksData.items.map((t) => t.duration_ms / 1e3);
        const meanDuration = durations.reduce((a, b) => a + b, 0) / durations.length;
        const durationStdDev = stdDev(durations);
        if (meanDuration >= 110 && meanDuration <= 190 && durationStdDev < 20) {
          signals.durationClustering = 20;
        } else if (meanDuration >= 100 && meanDuration <= 200 && durationStdDev < 30) {
          signals.durationClustering = 10;
        } else {
          signals.durationClustering = 0;
        }
        totalScore += signals.durationClustering;
      }
    }
  }
  if (artistData.genres.length === 0) {
    signals.noVerifiedProxy = 15;
  } else if (artistData.genres.length <= 1) {
    signals.noVerifiedProxy = 7;
  } else {
    signals.noVerifiedProxy = 0;
  }
  totalScore += signals.noVerifiedProxy;
  const score = Math.min(totalScore, 100);
  let status;
  if (score >= 80) {
    status = "auto-blocked";
  } else if (score >= 50) {
    status = "flagged";
  } else {
    status = "ignored";
  }
  return {
    score,
    signals,
    scoredAt: Date.now(),
    status
  };
}
function toFlaggedArtist(artist, score) {
  return {
    id: artist.id,
    name: artist.name,
    score: score.score,
    scoredAt: score.scoredAt
  };
}
async function enqueue(artistIds, failReason) {
  const queue = await storage.getRetryQueue();
  const existing = queue.find(
    (e) => JSON.stringify(e.artistIds.sort()) === JSON.stringify(artistIds.sort())
  );
  if (existing) {
    existing.attempts += 1;
    existing.lastAttemptAt = Date.now();
    existing.failReason = failReason;
  } else {
    queue.push({
      artistIds,
      failReason,
      attempts: 1,
      firstFailedAt: Date.now(),
      lastAttemptAt: Date.now()
    });
  }
  await storage.setRetryQueue(queue);
}
function isExpired(entry) {
  return Date.now() - entry.firstFailedAt > RETRY_EXPIRY_MS;
}
function isExhausted(entry) {
  return entry.attempts >= MAX_RETRY_ATTEMPTS;
}
async function processQueue(username, token) {
  const queue = await storage.getRetryQueue();
  if (queue.length === 0) return;
  const active = [];
  const stillFailing = [];
  for (const entry of queue) {
    if (isExpired(entry) || isExhausted(entry)) {
      continue;
    }
    active.push(entry);
  }
  for (const entry of active) {
    const artists = entry.artistIds.map((id) => ({ id, name: "" }));
    const result = await blockArtists(artists, username, token);
    if (result.blocked.length > 0) {
      await storage.addBlockedArtistIds(result.blocked);
    }
    if (result.failed.length > 0) {
      stillFailing.push({
        ...entry,
        artistIds: result.failed,
        attempts: entry.attempts + 1,
        lastAttemptAt: Date.now()
      });
    }
  }
  await storage.setRetryQueue(stillFailing);
}
let isSyncing = false;
async function runSyncPipeline() {
  if (isSyncing) return;
  isSyncing = true;
  try {
    const token = await storage.getAuthToken();
    const username = await storage.getUsername();
    if (!token || !username) {
      await storage.addError({ message: "No auth token — open Spotify first", context: "service-worker" });
      return;
    }
    const settings = await storage.getSettings();
    await processQueue(username, token);
    const syncResult = await fetchAndDiff(settings.csvSourceUrl);
    if (!syncResult) {
      return;
    }
    const { newArtists, removedArtists, fullList, sha } = syncResult;
    const whitelist = await storage.getWhitelistIds();
    const toBlock = newArtists.filter((a) => !whitelist.has(a.id));
    if (toBlock.length > 0) {
      const result = await blockArtists(toBlock, username, token);
      if (result.blocked.length > 0) {
        await storage.addBlockedArtistIds(result.blocked);
      }
      if (result.failed.length > 0) {
        await enqueue(result.failed, "block failed");
        await storage.addError({
          message: `Failed to block ${result.failed.length} artists — queued for retry`,
          context: "blocker"
        });
      }
    }
    if (settings.unblockRemovedArtists && removedArtists.length > 0) {
      const toUnblock = removedArtists.filter((a) => !whitelist.has(a.id));
      if (toUnblock.length > 0) {
        await unblockArtists(toUnblock.map((a) => a.id), username, token);
      }
    }
    await storage.setLastKnownArtistIds(fullList.map((a) => a.id));
    await storage.setLastSyncSha(sha);
    const nameMap = {};
    for (const a of fullList) {
      nameMap[a.id] = a.name;
    }
    await storage.setArtistNameMap(nameMap);
    await storage.clearErrors();
  } catch (err) {
    await storage.addError({
      message: err instanceof Error ? err.message : "Unknown sync error",
      context: "service-worker"
    });
  } finally {
    isSyncing = false;
  }
}
async function handleEncounteredArtists(artists) {
  const settings = await storage.getSettings();
  if (!settings.heuristicsEnabled) return;
  const token = await storage.getAuthToken();
  const username = await storage.getUsername();
  if (!token || !username) return;
  const csvIds = new Set(await storage.getLastKnownArtistIds());
  const blockedIds = new Set(await storage.getBlockedArtistIds());
  const whitelistIds = await storage.getWhitelistIds();
  const existingScores = await storage.getHeuristicScores();
  const toScore = artists.filter(
    (a) => !csvIds.has(a.id) && !blockedIds.has(a.id) && !whitelistIds.has(a.id) && !existingScores[a.id]
  );
  for (const artist of toScore) {
    const score = await scoreArtist(artist, token);
    if (!score) continue;
    await storage.setHeuristicScore(artist.id, score);
    if (score.score >= settings.autoBlockThreshold) {
      const result = await blockArtists([artist], username, token);
      if (result.blocked.length > 0) {
        await storage.addBlockedArtistIds(result.blocked);
      }
    } else if (score.score >= settings.flagThreshold) {
      await storage.addFlaggedArtist(toFlaggedArtist(artist, score));
    }
  }
}
function scheduleAlarm(frequencyHours) {
  chrome.alarms.create(ALARM_NAME, {
    periodInMinutes: frequencyHours * 60,
    delayInMinutes: 1
  });
}
chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === ALARM_NAME) {
    runSyncPipeline();
  }
});
chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message.type === "AUTH_TOKEN") {
    const { token, username } = message;
    (async () => {
      let resolvedUsername = username;
      if (!resolvedUsername) {
        try {
          const res = await fetch(`${SPOTIFY_API_BASE}/me`, {
            headers: { Authorization: token }
          });
          if (res.ok) {
            const data = await res.json();
            resolvedUsername = data.id ?? "";
          }
        } catch {
        }
      }
      await storage.setAuthToken(token, resolvedUsername);
      const existing = await chrome.alarms.get(ALARM_NAME);
      if (!existing) {
        const settings = await storage.getSettings();
        scheduleAlarm(settings.syncFrequencyHours);
      }
      runSyncPipeline();
    })();
    return false;
  }
  if (message.type === "TRIGGER_SYNC") {
    runSyncPipeline().then(() => sendResponse({ ok: true }));
    return true;
  }
  if (message.type === "GET_STATUS") {
    Promise.all([
      storage.getLastSyncTimestamp(),
      storage.getBlockCounts(),
      storage.getErrors(),
      storage.getFlaggedArtists()
    ]).then(([lastSync, counts, errors, flagged]) => {
      sendResponse({
        lastSync,
        sessionBlockCount: counts.session,
        totalBlockCount: counts.total,
        errors: errors.filter((e) => !e.resolved).slice(0, 5),
        flaggedArtists: flagged.slice(0, 10),
        isSyncing
      });
    });
    return true;
  }
  if (message.type === "WHITELIST_ARTIST") {
    storage.addToWhitelist({ id: message.id, name: message.name, addedAt: Date.now() }).then(() => storage.removeFlaggedArtist(message.id)).then(() => sendResponse({ ok: true }));
    return true;
  }
  if (message.type === "DISMISS_FLAGGED") {
    storage.removeFlaggedArtist(message.id).then(() => sendResponse({ ok: true }));
    return true;
  }
  if (message.type === "ARTISTS_ENCOUNTERED") {
    handleEncounteredArtists(message.artists);
    return false;
  }
  return false;
});
chrome.runtime.onInstalled.addListener(async () => {
  const settings = await storage.getSettings();
  scheduleAlarm(settings.syncFrequencyHours);
});
