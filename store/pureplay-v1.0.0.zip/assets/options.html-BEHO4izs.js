import "./modulepreload-polyfill-DaKOjhqt.js";
import { D as DEFAULT_SETTINGS, G as GITHUB_REPORT_URL } from "./constants-CvA2GUOI.js";
import { s as storage } from "./storage-DoDsk7hb.js";
const BLOCKED_PAGE_SIZE = 50;
let blockedDisplayCount = BLOCKED_PAGE_SIZE;
function el(id) {
  return document.getElementById(id);
}
function getInputValue(id) {
  return el(id).value.trim();
}
function getCheckboxValue(id) {
  return el(id).checked;
}
function setInputValue(id, value) {
  el(id).value = String(value);
}
function setCheckboxValue(id, value) {
  el(id).checked = value;
}
async function loadSettings() {
  const settings = await storage.getSettings();
  setInputValue("syncFrequencyHours", settings.syncFrequencyHours);
  setInputValue("csvSourceUrl", settings.csvSourceUrl);
  setCheckboxValue("unblockRemovedArtists", settings.unblockRemovedArtists);
  setCheckboxValue("heuristicsEnabled", settings.heuristicsEnabled);
  setInputValue("autoBlockThreshold", settings.autoBlockThreshold);
  setInputValue("flagThreshold", settings.flagThreshold);
  el("autoBlockThresholdValue").textContent = String(settings.autoBlockThreshold);
  el("flagThresholdValue").textContent = String(settings.flagThreshold);
  const whitelist = await storage.getWhitelist();
  el("whitelistInput").value = whitelist.map((e) => e.id).join("\n");
}
async function saveSettings() {
  const settings = {
    syncFrequencyHours: Math.max(1, parseInt(getInputValue("syncFrequencyHours"), 10) || 24),
    csvSourceUrl: getInputValue("csvSourceUrl") || DEFAULT_SETTINGS.csvSourceUrl,
    unblockRemovedArtists: getCheckboxValue("unblockRemovedArtists"),
    heuristicsEnabled: getCheckboxValue("heuristicsEnabled"),
    autoBlockThreshold: parseInt(getInputValue("autoBlockThreshold"), 10),
    flagThreshold: parseInt(getInputValue("flagThreshold"), 10)
  };
  await storage.setSettings(settings);
  chrome.alarms.clear("pureplay-sync", () => {
    chrome.alarms.create("pureplay-sync", {
      periodInMinutes: settings.syncFrequencyHours * 60,
      delayInMinutes: settings.syncFrequencyHours * 60
    });
  });
  const rawIds = el("whitelistInput").value.split("\n").map((l) => l.trim()).filter(Boolean);
  const existingWhitelist = await storage.getWhitelist();
  const existingIds = new Set(existingWhitelist.map((e) => e.id));
  for (const id of rawIds) {
    if (!existingIds.has(id)) {
      await storage.addToWhitelist({ id, name: id, addedAt: Date.now() });
    }
  }
  const saved = el("savedMsg");
  saved.classList.remove("hidden");
  setTimeout(() => saved.classList.add("hidden"), 2e3);
}
async function loadBlockedArtists(filter = "") {
  const blockedIds = await storage.getBlockedArtistIds();
  const nameMap = await storage.getArtistNameMap();
  const entries = blockedIds.map((id) => ({ id, name: nameMap[id] || "" }));
  const lowerFilter = filter.toLowerCase();
  const filtered = lowerFilter ? entries.filter(
    (e) => e.name.toLowerCase().includes(lowerFilter) || e.id.toLowerCase().includes(lowerFilter)
  ) : entries;
  el("blockedCount").textContent = lowerFilter ? `${filtered.length} of ${entries.length} artists` : `${entries.length} artists`;
  const list = el("blockedList");
  list.textContent = "";
  const toShow = filtered.slice(0, blockedDisplayCount);
  for (const entry of toShow) {
    const li = document.createElement("li");
    li.className = "blocked-item";
    const nameSpan = document.createElement("span");
    nameSpan.className = "blocked-item-name";
    nameSpan.textContent = entry.name || entry.id;
    const idSpan = document.createElement("span");
    idSpan.className = "blocked-item-id";
    idSpan.textContent = entry.id;
    const link = document.createElement("a");
    link.className = "blocked-item-link";
    link.textContent = "open";
    link.href = "https://open.spotify.com/artist/" + entry.id;
    link.target = "_blank";
    link.rel = "noopener";
    li.appendChild(nameSpan);
    li.appendChild(idSpan);
    li.appendChild(link);
    list.appendChild(li);
  }
  const moreBtn = el("blockedShowMore");
  if (filtered.length > blockedDisplayCount) {
    moreBtn.classList.remove("hidden");
    moreBtn.textContent = "Show more (" + (filtered.length - blockedDisplayCount) + " remaining)";
  } else {
    moreBtn.classList.add("hidden");
  }
}
function parseArtistId(input) {
  const trimmed = input.trim();
  const urlMatch = /\/artist\/([A-Za-z0-9]+)/.exec(trimmed);
  if (urlMatch) return urlMatch[1];
  if (/^[A-Za-z0-9]{22}$/.test(trimmed)) return trimmed;
  return null;
}
async function reportArtist() {
  const raw = getInputValue("reportArtistInput");
  const artistId = parseArtistId(raw);
  if (!artistId) {
    alert("Please enter a valid Spotify artist URL or ID.");
    return;
  }
  const reason = getInputValue("reportReason");
  const nameMap = await storage.getArtistNameMap();
  const artistName = nameMap[artistId] || "Unknown";
  const title = "Report AI artist: " + artistName + " (" + artistId + ")";
  const bodyLines = [
    "**Artist:** " + artistName,
    "**Spotify ID:** " + artistId,
    "**Spotify URL:** https://open.spotify.com/artist/" + artistId
  ];
  if (reason) bodyLines.push("**Reason:** " + reason);
  bodyLines.push("", "_Reported via PurePlay extension_");
  const body = bodyLines.join("\n");
  const url = GITHUB_REPORT_URL + "?title=" + encodeURIComponent(title) + "&body=" + encodeURIComponent(body);
  window.open(url, "_blank");
}
document.addEventListener("DOMContentLoaded", () => {
  loadSettings();
  el("autoBlockThreshold").addEventListener("input", (e) => {
    el("autoBlockThresholdValue").textContent = e.target.value;
  });
  el("flagThreshold").addEventListener("input", (e) => {
    el("flagThresholdValue").textContent = e.target.value;
  });
  el("saveBtn").addEventListener("click", saveSettings);
  el("exportWhitelist").addEventListener("click", async () => {
    const whitelist = await storage.getWhitelist();
    const data = JSON.stringify(whitelist, null, 2);
    const blob = new Blob([data], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "pureplay-whitelist.json";
    a.click();
    URL.revokeObjectURL(url);
  });
  el("importWhitelist").addEventListener("click", () => {
    const input = document.createElement("input");
    input.type = "file";
    input.accept = ".json";
    input.addEventListener("change", async () => {
      var _a;
      const file = (_a = input.files) == null ? void 0 : _a[0];
      if (!file) return;
      try {
        const text = await file.text();
        const entries = JSON.parse(text);
        for (const entry of entries) {
          if (entry.id) {
            await storage.addToWhitelist({ id: entry.id, name: entry.name ?? entry.id, addedAt: Date.now() });
          }
        }
        await loadSettings();
      } catch {
        alert("Invalid whitelist file.");
      }
    });
    input.click();
  });
  el("clearAll").addEventListener("click", async () => {
    if (confirm("Clear all PurePlay data? This cannot be undone.")) {
      await storage.clearAll();
      await loadSettings();
      await loadBlockedArtists();
    }
  });
  loadBlockedArtists();
  let searchTimer = null;
  el("blockedSearch").addEventListener("input", (e) => {
    if (searchTimer !== null) clearTimeout(searchTimer);
    blockedDisplayCount = BLOCKED_PAGE_SIZE;
    searchTimer = window.setTimeout(() => {
      loadBlockedArtists(e.target.value);
    }, 300);
  });
  el("blockedShowMore").addEventListener("click", () => {
    blockedDisplayCount += BLOCKED_PAGE_SIZE;
    loadBlockedArtists(el("blockedSearch").value);
  });
  el("reportBtn").addEventListener("click", reportArtist);
});
